﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Xml;


namespace LitasSEPAWindowsService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }

        #region Set Windows Service Names from config file
        private void setKeyValues()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(System.Reflection.Assembly.GetExecutingAssembly().Location + ".config");
            XmlNode node = doc.SelectSingleNode("/configuration/appSettings/add[@key='ServiceName']");
            serviceInstaller.ServiceName = node.Attributes.GetNamedItem("value").Value.ToString();
            System.Diagnostics.Debug.WriteLine(serviceInstaller.ServiceName);
            node = doc.SelectSingleNode("/configuration/appSettings/add[@key='DisplayName']");
            serviceInstaller.DisplayName = node.Attributes.GetNamedItem("value").Value.ToString();
            System.Diagnostics.Debug.WriteLine(serviceInstaller.DisplayName);
        }
        #endregion

        private void ProjectInstaller_BeforeInstall(object sender, InstallEventArgs e)
        {
            setKeyValues();
        }

        private void ProjectInstaller_BeforeUninstall(object sender, InstallEventArgs e)
        {
            setKeyValues();
        }

        private void processInstaller_AfterInstall(object sender, InstallEventArgs e)
        {

        }
    }
}

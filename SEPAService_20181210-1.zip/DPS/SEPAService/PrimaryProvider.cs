﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LitasSEPAWindowsService
{
    class PrimaryProvider
    {

        public LitasSEPAProvider sepaProvider;

        public PrimaryProvider()
        {
            sepaProvider = new LitasSEPAProvider();
        }

        public Boolean Initialize()
        {
            sepaProvider.Initialize();
            return true;
        }
    }
}

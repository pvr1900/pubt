﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Web;

namespace LitasSEPAWindowsService
{
    public class LitasSEPAProvider
    {
        #region Sms provider fields
        public String MsgPath;
        public int priority;
        protected string providerName;
        #endregion

        #region Database connection fields
        public String sqlServer;
        public String sqlFailover;
        public String sqlDatabase;
        public String sqlUser;
        public String sqlPassword;
        #endregion

        public String filename;

        public virtual Boolean Initialize()
        {
            providerName = "";

            #region Service settings
            filename = ConfigurationManager.AppSettings["LogFileName"];
            if (filename == null)
                return false;
            #endregion

            #region Priority
            int.TryParse(ConfigurationManager.AppSettings[providerName+"Priority"], out priority);
            if (priority == 0)
                WriteLog("Priority is not set");
            #endregion

            #region  provider settings
            MsgPath = ConfigurationManager.AppSettings[providerName+ "MsgPath"];
            if (MsgPath == null)
            {
                WriteLog("MsgPath is not set");
                return false;
            }
            #endregion

            #region Sql server settings
            sqlServer = ConfigurationManager.AppSettings["sqlServer"];
            if (sqlServer == null)
            {
                WriteLog("Sql server is not set");
                return false;
            }
            sqlFailover = ConfigurationManager.AppSettings["sqlFailover"];
            if (sqlFailover == null)
                WriteLog("Failover sql server is not set");
            sqlDatabase = ConfigurationManager.AppSettings["sqlDatabase"];
            if (sqlDatabase == null)
            {
                WriteLog("Sql database is not set");
                return false;
            }
            sqlUser = ConfigurationManager.AppSettings["sqlUser"];
            if (sqlUser == null)
            {
                WriteLog("Sql user is not set");
                return false;
            }
            sqlPassword = ConfigurationManager.AppSettings["sqlPassword"];
            if (sqlPassword == null)
                sqlPassword = "";  //Set empty password for default
            #endregion

            return true;
        }

        #region Logging service
        public void WriteLog(String message)
        {
            if (!File.Exists(filename))
                return;

            FileStream stream = new FileStream(filename, FileMode.Append);
            DateTime logDate = DateTime.Now;
            String logMessage = "\r\n" + logDate.ToShortDateString() +
                " " + logDate.ToLongTimeString() + " " + this.GetType().Name.PadRight(10) + " : " + message;
            byte[] logMessageBytes = new UTF8Encoding(true).GetBytes(logMessage);
            stream.Write(logMessageBytes, 0, logMessageBytes.Length);
            stream.Close();
        }
        #endregion

    }

}

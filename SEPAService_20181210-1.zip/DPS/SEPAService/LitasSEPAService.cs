﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.Xml;
using System.Linq;
using System.Collections.Generic;

namespace LitasSEPAWindowsService
{
    public partial class LitasSEPAService : ServiceBase
    {
        public LitasSEPAService()
        {
            InitializeComponent();
            
        }

        private HashSet<string> processedFiles = new HashSet<string>();


        Timer serviceTimer;
        PrimaryProvider primaryProvider;
        public LitasSEPAProvider sepaProvider
        {
            get { return primaryProvider.sepaProvider; }
        }

        public Boolean Initialize()
        {
            #region Create SMS providers
            primaryProvider = new PrimaryProvider();
            if (!primaryProvider.Initialize())
                return false;
            #endregion
            #region Timer setup
            String timerIntervalStr = ConfigurationManager.AppSettings["TimerInterval"];
            if (timerIntervalStr == null)
            {
                sepaProvider.WriteLog("Timer interval is not set");
                return false;
            }
            serviceTimer = new Timer();
            serviceTimer.Interval = Double.Parse(timerIntervalStr);
            serviceTimer.Elapsed += new ElapsedEventHandler(serviceTimer_Elapsed);
            serviceTimer.Start();
            #endregion

            return true;
        }

        Boolean isBusy;

        #region ServiceBase methods
        protected override void OnStart(string[] args)
        {
            if (!Initialize())
            {
                this.Stop();
            }
            sepaProvider.WriteLog("Service started");

        }

        protected override void OnStop()
        {
            if (serviceTimer != null)
                serviceTimer.Stop();
            serviceTimer.Dispose();
            sepaProvider.WriteLog("Service stopped");
        }

        protected override void OnPause()
        {
            serviceTimer.Stop();
        }

        protected override void OnContinue()
        {
            serviceTimer.Start();
        }
        #endregion

        #region Database monitor section
        public void PollDatabase()
        {
            isBusy = true;
            try
            { 
                SqlConnectionStringBuilder connStrBuilder = new SqlConnectionStringBuilder();
                connStrBuilder.DataSource = sepaProvider.sqlServer;
                if (sepaProvider.sqlFailover!=null)
                    connStrBuilder.FailoverPartner = sepaProvider.sqlFailover;
                connStrBuilder.InitialCatalog = sepaProvider.sqlDatabase;
                connStrBuilder.UserID = sepaProvider.sqlUser;
                connStrBuilder.Password = sepaProvider.sqlPassword;

                //sepaProvider.WriteLog("Poll Connstr:"+ connStrBuilder.ConnectionString);
                SqlConnection sqlConn = new SqlConnection(connStrBuilder.ConnectionString);
                SqlCommand sqlComm = new SqlCommand();
                sqlComm.Connection = sqlConn;
                sqlComm.CommandType = CommandType.Text;
                sqlComm.CommandText = "select dd.id, dd.MsgType type, dd.SEPA_Request request "+
                    "from Documents d, DocDataSEPA_Outgoing dd , DocPathFolders dpf "+
                    "where d.DocPathFolderID = dpf.id and dd.id = d.id and dpf.FolderUID = 333";
                try
                {
                    sqlComm.Connection.Open();
                    SqlDataReader reader = sqlComm.ExecuteReader();
                    while (reader.Read())
                    {
                        String docid = reader["id"].ToString();
                        String type = reader["type"].ToString();
                        String fileName =  type + "-" + docid + ".xml";
                        if (type.Equals("")) fileName = docid + ".xml";


                        String request = reader["request"] != null ? reader["request"].ToString() : "";
                        sepaProvider.WriteLog("Saving request for document : " + docid);


                        String resultFile = sepaProvider.MsgPath + Path.DirectorySeparatorChar + "Outbox" + Path.DirectorySeparatorChar + fileName;
                        using (StreamWriter sw = File.CreateText(resultFile))
                        {
                            sw.WriteLine(request);
                        }

                        SqlCommand updateComm = new SqlCommand(
                                "sp_DocFlowApplyDefMethod",
                                new SqlConnection(connStrBuilder.ConnectionString));
                        updateComm.CommandType = CommandType.StoredProcedure;
                        updateComm.Parameters.Add("@DocumentID", SqlDbType.Int);
                        updateComm.Parameters["@DocumentID"].Value = docid;
                        updateComm.Connection.Open();
                        updateComm.ExecuteNonQuery();
                        updateComm.Connection.Close();
                    

                    }
                    sqlComm.Connection.Close();
                    isBusy = false;
                }
                catch (Exception excp)
                {
                    sepaProvider.WriteLog("Error polling database: " + excp.Message);
                    isBusy = false;
                }
            }
            finally
            {
                isBusy = false;
            }
        }
        #endregion

        public void PollIncoming()
        {
            isBusy = true;

            try
            {
                string[] fileEntries;

                fileEntries = Directory.GetFiles(sepaProvider.MsgPath + Path.DirectorySeparatorChar + "Errors");
                foreach (string fileName in fileEntries)
                    ProcessFile(fileName);

                fileEntries = Directory.GetFiles(sepaProvider.MsgPath + Path.DirectorySeparatorChar + "SendResult");
                foreach (string fileName in fileEntries)
                    ProcessFile(fileName);

                fileEntries = Directory.GetFiles(sepaProvider.MsgPath + Path.DirectorySeparatorChar + "Inbox");
                foreach (string fileName in fileEntries)
                    ProcessFile(fileName);

            }
            finally
            {
                isBusy = false;
            }
        }

        void ProcessFile(string fileName)
        {
            //if (processedFiles.Contains(fileName)) return;

            sepaProvider.WriteLog("Processing: " + fileName);

            SqlConnectionStringBuilder connStrBuilder = new SqlConnectionStringBuilder();
            connStrBuilder.DataSource = sepaProvider.sqlServer;
            if (sepaProvider.sqlFailover != null)
                connStrBuilder.FailoverPartner = sepaProvider.sqlFailover;
            connStrBuilder.InitialCatalog = sepaProvider.sqlDatabase;
            connStrBuilder.UserID = sepaProvider.sqlUser;
            connStrBuilder.Password = sepaProvider.sqlPassword;
            //sepaProvider.WriteLog("Connstr:"+ connStrBuilder.ConnectionString);

            try
            {
                processedFiles.Add(fileName);
                string report = File.ReadAllText(fileName);

                SqlCommand updateComm = new SqlCommand(
                        "sp_LITAS_New_Incoming",
                        new SqlConnection(connStrBuilder.ConnectionString));
                updateComm.CommandType = CommandType.StoredProcedure;
                updateComm.Parameters.Add("@Source", SqlDbType.NVarChar, -1/*max*/);
                updateComm.Parameters.Add("@FileName", SqlDbType.NVarChar, -1/*max*/);
                updateComm.Parameters.Add("@FileData", SqlDbType.NVarChar, -1/*max*/);
                updateComm.Parameters["@Source"].Value = Path.GetFileName(Path.GetDirectoryName(fileName));
                updateComm.Parameters["@FileName"].Value = Path.GetFileName(fileName);
                updateComm.Parameters["@FileData"].Value = report;
                updateComm.Parameters.Add("@NewDocumentID", SqlDbType.Int).Direction = ParameterDirection.Output;
                updateComm.Connection.Open();
                updateComm.ExecuteNonQuery();
                
                sepaProvider.WriteLog("   New Incoming Doc:" + updateComm.Parameters["@NewDocumentID"].Value.ToString());
                updateComm.Connection.Close();

                File.Move(fileName, Path.GetDirectoryName(fileName)+"Archive" + Path.DirectorySeparatorChar + Path.GetFileName(fileName));
            }
            catch (Exception excp)
            {
                sepaProvider.WriteLog("Error processing file :" + excp.Message + " st:" + excp.StackTrace);
                File.Move(fileName, Path.GetDirectoryName(Path.GetDirectoryName(fileName)) + Path.DirectorySeparatorChar + "Unprocessed" + Path.DirectorySeparatorChar + Path.GetFileName(fileName));
                isBusy = false;
            }


        }

        #region Timer event
        void serviceTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            bool write;
            if (!isBusy)
            {
                write=Math.Min(1, DateTime.Now.Second)<=0;
                /*if (write)  *///sepaProvider.WriteLog("Poll database for new messages");
                PollDatabase();
                PollIncoming();
                /*if (write)  *///sepaProvider.WriteLog("Database poll completed");
            }
        }
        #endregion
    }
}

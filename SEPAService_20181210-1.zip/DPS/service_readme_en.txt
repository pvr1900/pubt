Installation notes:

- extract this to disk C: (preffered) or D: or any other

- LITAS Service executable is in folderDPS\SEPAService\bin\Release    
  to install it run the command:
  c:\Windows\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe c:\DPS\SEPAService\bin\Release\LitasSEPAWindowsService.exe

- In config file c:\DPS\SEPAService\bin\Release\LitasSEPAWindowsService.exe.config
  change IP address of SQL server, username, password,
  optionally path to DPS folder and path to log files
  
- start the service

- check log file for errors
  
- don't run two services on the same database ! 


